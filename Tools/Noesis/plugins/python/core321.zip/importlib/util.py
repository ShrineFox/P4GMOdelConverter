"""Utility code for constructing importers, etc."""

from ._bootstrap import module_for_loader
from ._bootstrap import set_loader
from ._bootstrap import set_package
