Noesis Plugin DLL source code.
